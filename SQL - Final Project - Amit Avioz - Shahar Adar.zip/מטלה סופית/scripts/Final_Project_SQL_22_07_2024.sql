﻿use project
go

-- כמות מבקרים לכל גן חיות
create or alter view Visitors_Counter
as
	SELECT dbo.Zoos.zoo_name, dbo.ZoosVisitors.zoo_id, COUNT(dbo.ZoosVisitors.visitor_id) AS [Visitors Counter]
	FROM     dbo.Zoos INNER JOIN
					  dbo.ZoosVisitors ON dbo.Zoos.zoo_id = dbo.ZoosVisitors.zoo_id
	GROUP BY dbo.Zoos.zoo_name, dbo.ZoosVisitors.zoo_id
go

select * from Visitors_Counter
go

-- חיבור בין טבלת העובדים לבין טבלת גני החיות
create or alter view ZooEmployees
as
	select Zoos.zoo_id, Zoos.zoo_name, first_name, last_name, salary from Zoos, Employees
	where Zoos.zoo_id = Employees.zoo_id
go

-- פונקציה שמחשבת הוצאות לכל גן חיות, בהתאם לבחירת המשתמש של גן חיות
create function OutcomesPerZoo (@zoo_name nvarchar (40))
returns decimal (16, 2)
	begin
		declare @total_outcomes decimal (16, 2)
		select @total_outcomes = sum(salary) from Employees, Zoos
						where (Employees.zoo_id = Zoos.zoo_id)
						and (Zoos.zoo_name = @zoo_name)
		return @total_outcomes
	end
go

-- הרצת הפונקציה לחישוב הוצאות לגן חיות ספציפי
select dbo.OutcomesPerZoo ('Pairi Daiza') as 'Outcomes'
go

-- יצירת טבלה המרכזת את כל ההוצאות של כל גני החיות
create or alter function Zoos_OutComes_Total ()
returns @Zoos_Outcomes table
	(zoo_id int, Zoo_name varchar(100), outcomes float)
as
	begin
		declare @counter int, @counter_end int
		declare @zoo_name varchar (100)
		declare @outcomes float
		select @counter = zoo_id from Zoos order by zoo_id desc
		select @counter_end = zoo_id from Zoos order by zoo_id
		while @counter <= @counter_end
			begin
				select @Zoo_name = zoo_name from Zoos where zoo_id = @counter
				select @outcomes = dbo.OutcomesPerZoo(@zoo_name)
				insert @Zoos_Outcomes
				values (@counter, @zoo_name, @outcomes)
				set @counter = @counter + 1
			end
		return
	end
go

-- בדיקת הפונקציה מעל
select * from Zoos_OutComes_Total()

-- יצירת טבלת עזר כדי לשמור את ההוצאות
create table Zoos_Outcomes(
	zoo_id int,
	zoo_name varchar(100),
	outcomes float,
	PRIMARY KEY (zoo_id),
    FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id),
)

-- יצירת פרוצדורה בשביל ליצור טבלת הוצאות *לא נדיפה* ולשמור את התוצאות
create or alter proc Create_Zoos_Outcomes_Table 
as
	insert Zoos_Outcomes
	select * from Zoos_OutComes_Total()
go

-- הרצת הפרוצדורה מעל
exec Create_Zoos_Outcomes_Table

-- עבור גן החיות עם הכי הרבה מבקרים, העובדים יקבלו בונוס של 10% למשכורת
create or alter proc Raise_Employees_Salary
as
	declare @best_zoo_name varchar(100)
	select top 1 @best_zoo_name =  zoo_name from Visitors_Counter order by [Visitors Counter] desc 
	begin transaction
		update Employees set salary = salary * 1.1 where Employees.zoo_id = (select zoo_id from ZooEmployees where zoo_name = @best_zoo_name group by zoo_id)
		if (@@ERROR <> 0)
			begin
				rollback transaction
				return
			end
	commit transaction
go

-- הפעלת הפרוצדורה - בונוס העלאת המשכורת ב-10%
exec Raise_Employees_Salary
select * from Employees

-- מחיקת טריגר "עדכון טבלת עובדים" אם קיים
IF EXISTS ( SELECT name FROM sysobjects
			WHERE type = 'TR' AND name = 'Employees_Salary_Update' )
DROP TRIGGER Employees_Salary_Update
go

-- יצירת טריגר לעדכון "הוצאות לכל גן חיות" לאחר שינוי משכורת העובדים
create or alter trigger Employees_Salary_Update
	on Employees for update
as
	if update(Salary)
		begin
			declare @new_outcomes float, @zoo_id int
			select @new_outcomes = (select sum(salary) from inserted)
			select @zoo_id = (select zoo_id from inserted group by zoo_id)
			update zoos_outcomes set outcomes = @new_outcomes where zoo_id = @zoo_id
		end
go

-- חיבור בין הטבלאות של גני חיות וחיות
create or alter view AnimalsInZoosFull
as
	SELECT dbo.Animals.animal_name, dbo.Animals.medical, dbo.Animals.birth_date, dbo.Animals.origin, dbo.Animals.type, dbo.Zoos.zoo_name, dbo.Zoos.city, dbo.Zoos.country, dbo.Zoos.ticket_price, dbo.Zoos.manager
	FROM     dbo.Animals INNER JOIN
			 dbo.ZoosAnimals ON dbo.Animals.animal_id = dbo.ZoosAnimals.animal_id INNER JOIN
			 dbo.Zoos ON dbo.ZoosAnimals.zoo_id = dbo.Zoos.zoo_id INNER JOIN
			 dbo.Animals AS Animals_1 ON dbo.ZoosAnimals.animal_id = Animals_1.animal_id INNER JOIN
		     dbo.Zoos AS Zoos_1 ON dbo.ZoosAnimals.zoo_id = Zoos_1.zoo_id INNER JOIN
			 dbo.ZoosAnimals AS ZoosAnimals_1 ON dbo.Animals.animal_id = ZoosAnimals_1.animal_id AND dbo.Zoos.zoo_id = ZoosAnimals_1.zoo_id AND Animals_1.animal_id = ZoosAnimals_1.animal_id AND Zoos_1.zoo_id = ZoosAnimals_1.zoo_id
go

select * from AnimalsInZoosFull

-- הצגת כל החיות מסוג מסויים (לדוגמה: יונק) עבור גן חיות מסויים, על פי בחירת המשתמש
create or alter function AnimalsByTypeFromZoo (@zoo_name nvarchar(40), @animal_type nvarchar (20))
returns @AnimalsByType table
	(animal_name varchar(100), origin varchar(100), type varchar(50), zoo_name varchar(100))
as
begin
	insert @AnimalsByType
	select animal_name, origin, type, zoo_name 
	from AnimalsInZoosFull
	where zoo_name = @zoo_name
	and type = @animal_type
	return
end
go

-- בדיקת הפונקציה הנ"ל
select * from AnimalsByTypeFromZoo ('Singapore Zoo', 'Mammal')
go

-- חיבור הטבלאות חיות אהובות ומבקרים
create or alter view FavoriteAnimalsFullInfo
as
	SELECT dbo.Visitors.first_name, dbo.Visitors.last_name, dbo.Animals.animal_id, dbo.Animals.animal_name, dbo.Animals.medical, dbo.Animals.birth_date, dbo.Animals.type, dbo.Animals.origin
	FROM     dbo.Animals INNER JOIN
                  dbo.FavoriteAnimals ON dbo.Animals.animal_id = dbo.FavoriteAnimals.animal_id INNER JOIN
                  dbo.Visitors ON dbo.FavoriteAnimals.visitor_id = dbo.Visitors.visitor_id
go

-- הצגת החיה הכי אהובה
select animal_name, count(animal_id) as [Counter] from FavoriteAnimalsFullInfo group by animal_id, animal_name order by Counter desc

-- יצירת טבלת עזר הכנסות
create table Tbl_Tot_Income
(
	zoo_id int,
	zoo_name varchar (100),
	tot_income float,
	PRIMARY KEY (zoo_id),
    FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id),
)

-- פרוצדורה למחיקת טבלת העזר
create or alter proc Proc_Del_Tbl_Tot
	as
		Delete from Tbl_Tot_Income
go

-- פרוצדורה היוצרת טבלת הכנסות עבור גן חיות ע"פ בחירת המשתמש
create or alter proc Income_Per_Zoo 
	@zoo_name varchar(100)
as
	select Zoos.zoo_id, Zoos.zoo_name, (ticket_price * [Visitors Counter]) as 'Income' from Zoos, Visitors_Counter
	where (Zoos.zoo_id = Visitors_Counter.zoo_id)
	and Zoos.zoo_name = @zoo_name
go

-- פרוצדורה ליצירת טבלת הכנסות כוללת לכל גני החיות
create or alter proc total_income_per_zoo
as
	exec Proc_Del_Tbl_Tot
	declare @counter int, @counter_end int
	declare @zoo_name varchar (100)
	select @counter = zoo_id from Zoos order by zoo_id desc
	select @counter_end = zoo_id from Zoos order by zoo_d
	while @counter <= @counter_end
		begin
			select @Zoo_name = zoo_name from Zoos where zoo_id = @counter
			insert Tbl_Tot_Income
			exec Income_Per_Zoo @zoo_name
			set @counter = @counter + 1
		end
go

-- הפעלת הפרוצדורה הנ"ל
exec total_income_per_zoo
select * from Tbl_Tot_Income order by tot_income desc

-------------------------------------
-- גיבוי
EXEC sp_configure 'show advanced options', 1
RECONFIGURE
GO

sp_configure 'xp_cmdshell','1'
RECONFIGURE with override
Go

-- יצירת הגיבוי
DECLARE @Name VARCHAR(50) -- database name
DECLARE @path VARCHAR(256) -- path for backup files
DECLARE @fileName VARCHAR(256) -- filename for backup
DECLARE @fileDate VARCHAR(20) -- used for file name
SET @Name = db_name()
SET @Path = 'C:\SQL\FinalProject\'
Declare @dir varchar(50)
Set @dir = 'MD ' + @path
EXEC xp_cmdshell @dir
SELECT @fileDate = CONVERT(VARCHAR(8),GETDATE(),112)
SET @fileName = @path + @name + '_' + substring(@fileDate, 1, 4) + '_'
									+ SUBSTRING(@fileDate, 5, 2) + '_'
									+ substring(@fileDate, 7, 2) + '_'
									+ substring(convert(char(8), getdate(), 108), 1, 2) + '_'
									+ substring(convert(char(8), getdate(), 108), 4, 2) + '_'
									+ substring(convert(char(8), getdate(), 108), 7, 2) +
									'.BAK'
print @fileName
BACKUP DATABASE @name TO DISK = @fileName

------------------------------------------------
---- הפעלת יצוא לטבלה אחת מסוימת ---
Declare @table_name varchar(50)
Declare @file_name varchar(50)
Declare @command varchar(200)
Set @table_name = 'Zoos_Outcomes'
Set @file_name = 'C:\SQL\FinalProject\' + @table_name + '.xls'
-- תחביר לרופין ---
Set @command='bcp '+db_name()+'.dbo.'+@table_name+' out '+@file_name+' -c -N -w -T -S (local)'
Print @command
-- פקודת היצוא לאקסל ---
Exec master..xp_cmdshell @command
GO

--------------------------------
-- ייבוא טבלת אקסל - הזמנות של מוצרי מזון שונים עבור החיות
drop table orders
create table Orders
(
	order_id int primary key,
	product varchar(50) not null, 
	quantity int not null,
	price int not null,
	zoo_id int not null
	FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id)
)

BULK INSERT Orders
FROM 'C:\SQL\FinalProject\Orders.csv'
WITH
(
	codepage = 'ACP',
	firstrow = 2,
	maxerrors = 0,
	fieldterminator = ',',
	rowterminator = '\n'
)
GO

-- בדיקה שהייבוא הצליח
select * from Orders

-- מחיקת טריגר "עדכון הוצאות לכל גן חיות" אם קיים
IF EXISTS ( SELECT name FROM sysobjects
			WHERE type = 'TR' AND name = 'Orders_Insert' )
DROP TRIGGER Orders_Insert
go

-- לאחר יצירת הזמנה חדשה, ניצור טריגר לעדכון הוצאות לכל גן חיות
create or alter trigger Orders_Insert
	on Orders for insert
as
	update Zoos_Outcomes
	set outcomes = (Zoos_Outcomes.outcomes + inserted.price)
	from Zoos_Outcomes inner join inserted
	on Zoos_Outcomes.zoo_id = inserted.zoo_id
go

select * from orders
select * from Zoos_Outcomes

-- בדיקת הטריגר
insert Orders (order_id, product, quantity, price, zoo_id)
values (16, 'fruits', 900, 800, 74)

select * from orders
select * from Zoos_Outcomes

-- פונקציית חלון המציגה סכום הוצאות מצטבר עבור כל גן חיות
Select order_id, product, quantity, price, zoo_id,
	sum(price) over (partition by zoo_id order by price) as sum_of_customer_orders_Miz
From orders
Go

-- איחוד הטבלאות מבקרים וגני חיות
create or alter view VisitorsInZoos
as
	SELECT dbo.Zoos.zoo_name, dbo.Visitors.first_name, dbo.Visitors.last_name, dbo.Visitors.visit_date, dbo.Visitors.visitor_id
	FROM     dbo.Visitors INNER JOIN
                  dbo.ZoosVisitors ON dbo.Visitors.visitor_id = dbo.ZoosVisitors.visitor_id INNER JOIN
                  dbo.Zoos ON dbo.ZoosVisitors.zoo_id = dbo.Zoos.zoo_id
go

select * from VisitorsInZoos

-- הצגת מספר המבקרים המצטבר בכל גן חיות, בין שני תאריכים לפי בחירת המשתמש
create or alter proc Visitors_Over_Dates 
(@month int, @day_from int, @day_until int)
as
	select *, count(visitor_id) over (partition by zoo_name order by visit_date) as Visitor_Counter
	from VisitorsInZoos
	where month(visit_date) = @month 
	and day(visit_date) > @day_from
	and day(visit_date) < @day_until
go

-- הפעלת הפרוצדורה הנ"ל
exec Visitors_Over_Dates 6, 15, 20

-- שחזור הדאטה בייס
USE [master]
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = 'Project')
DROP DATABASE Project
GO
RESTORE DATABASE Project
FROM DISK = 'C:\SQL\FinalProject\Project_2024_07_22_11_47_09.bak'
GO