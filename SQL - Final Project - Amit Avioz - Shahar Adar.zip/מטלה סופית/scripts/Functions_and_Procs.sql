﻿-- פונקציה שמחשבת הוצאות לכל גן חיות, בהתאם לבחירת המשתמש של גן חיות
create function OutcomesPerZoo (@zoo_name nvarchar (40))
returns decimal (16, 2)
	begin
		declare @total_outcomes decimal (16, 2)
		select @total_outcomes = sum(salary) from Employees, Zoos
						where (Employees.zoo_id = Zoos.zoo_id)
						and (Zoos.zoo_name = @zoo_name)
		return @total_outcomes
	end
go

-- הרצת הפונקציה לחישוב הוצאות לגן חיות ספציפי
select dbo.OutcomesPerZoo ('Pairi Daiza') as 'Outcomes'
go

-- יצירת טבלה המרכזת את כל ההוצאות של כל גני החיות
create or alter function Zoos_OutComes_Total ()
returns @Zoos_Outcomes table
	(zoo_id int, Zoo_name varchar(100), outcomes float)
as
	begin
		declare @counter int, @counter_end int
		declare @zoo_name varchar (100)
		declare @outcomes float
		select @counter = zoo_id from Zoos order by zoo_id desc
		select @counter_end = zoo_id from Zoos order by zoo_id
		while @counter <= @counter_end
			begin
				select @Zoo_name = zoo_name from Zoos where zoo_id = @counter
				select @outcomes = dbo.OutcomesPerZoo(@zoo_name)
				insert @Zoos_Outcomes
				values (@counter, @zoo_name, @outcomes)
				set @counter = @counter + 1
			end
		return
	end
go

-- בדיקת הפונקציה מעל
select * from Zoos_OutComes_Total()

-- יצירת פרוצדורה בשביל ליצור טבלת הוצאות *לא נדיפה* ולשמור את התוצאות
create or alter proc Create_Zoos_Outcomes_Table 
as
	insert Zoos_Outcomes
	select * from Zoos_OutComes_Total()
go

-- הרצת הפרוצדורה מעל
exec Create_Zoos_Outcomes_Table

-- עבור גן החיות עם הכי הרבה מבקרים, העובדים יקבלו בונוס של 10% למשכורת
create or alter proc Raise_Employees_Salary
as
	declare @best_zoo_name varchar(100)
	select top 1 @best_zoo_name =  zoo_name from Visitors_Counter order by [Visitors Counter] desc 
	begin transaction
		update Employees set salary = salary * 1.1 where Employees.zoo_id = (select zoo_id from ZooEmployees where zoo_name = @best_zoo_name group by zoo_id)
		if (@@ERROR <> 0)
			begin
				rollback transaction
				return
			end
	commit transaction
go

-- הפעלת הפרוצדורה - בונוס העלאת המשכורת ב-10%
exec Raise_Employees_Salary
select * from Employees

-- הצגת כל החיות מסוג מסויים (לדוגמה: יונק) עבור גן חיות מסויים, על פי בחירת המשתמש
create or alter function AnimalsByTypeFromZoo (@zoo_name nvarchar(40), @animal_type nvarchar (20))
returns @AnimalsByType table
	(animal_name varchar(100), origin varchar(100), type varchar(50), zoo_name varchar(100))
as
begin
	insert @AnimalsByType
	select animal_name, origin, type, zoo_name 
	from AnimalsInZoosFull
	where zoo_name = @zoo_name
	and type = @animal_type
	return
end
go

-- בדיקת הפונקציה הנ"ל
select * from AnimalsByTypeFromZoo ('Singapore Zoo', 'Mammal')
go


-- פרוצדורה למחיקת טבלת העזר
create or alter proc Proc_Del_Tbl_Tot
	as
		Delete from Tbl_Tot_Income
go

-- פרוצדורה היוצרת טבלת הכנסות עבור גן חיות ע"פ בחירת המשתמש
create or alter proc Income_Per_Zoo 
	@zoo_name varchar(100)
as
	select Zoos.zoo_id, Zoos.zoo_name, (ticket_price * [Visitors Counter]) as 'Income' from Zoos, Visitors_Counter
	where (Zoos.zoo_id = Visitors_Counter.zoo_id)
	and Zoos.zoo_name = @zoo_name
go

-- פרוצדורה ליצירת טבלת הכנסות כוללת לכל גני החיות
create or alter proc total_income_per_zoo
as
	exec Proc_Del_Tbl_Tot
	declare @counter int, @counter_end int
	declare @zoo_name varchar (100)
	select @counter = zoo_id from Zoos order by zoo_id desc
	select @counter_end = zoo_id from Zoos order by zoo_d
	while @counter <= @counter_end
		begin
			select @Zoo_name = zoo_name from Zoos where zoo_id = @counter
			insert Tbl_Tot_Income
			exec Income_Per_Zoo @zoo_name
			set @counter = @counter + 1
		end
go

-- הפעלת הפרוצדורה הנ"ל
exec total_income_per_zoo
select * from Tbl_Tot_Income order by tot_income desc


-- הצגת מספר המבקרים המצטבר בכל גן חיות, בין שני תאריכים לפי בחירת המשתמש
create or alter proc Visitors_Over_Dates 
(@month int, @day_from int, @day_until int)
as
	select *, count(visitor_id) over (partition by zoo_name order by visit_date) as Visitor_Counter
	from VisitorsInZoos
	where month(visit_date) = @month 
	and day(visit_date) > @day_from
	and day(visit_date) < @day_until
go

-- הפעלת הפרוצדורה הנ"ל
exec Visitors_Over_Dates 6, 15, 20