﻿------------------------------------------------
---- הפעלת יצוא לטבלה אחת מסוימת ---
Declare @table_name varchar(50)
Declare @file_name varchar(50)
Declare @command varchar(200)
Set @table_name = 'Zoos_Outcomes'
Set @file_name = 'C:\SQL\FinalProject\' + @table_name + '.xls'
-- תחביר לרופין ---
Set @command='bcp '+db_name()+'.dbo.'+@table_name+' out '+@file_name+' -c -N -w -T -S (local)'
Print @command
-- פקודת היצוא לאקסל ---
Exec master..xp_cmdshell @command
GO

--------------------------------
-- ייבוא טבלת אקסל - הזמנות של מוצרי מזון שונים עבור החיות
drop table orders
create table Orders
(
	order_id int primary key,
	product varchar(50) not null, 
	quantity int not null,
	price int not null,
	zoo_id int not null
	FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id)
)

BULK INSERT Orders
FROM 'C:\SQL\FinalProject\Orders.csv'
WITH
(
	codepage = 'ACP',
	firstrow = 2,
	maxerrors = 0,
	fieldterminator = ',',
	rowterminator = '\n'
)
GO

-- בדיקה שהייבוא הצליח
select * from Orders