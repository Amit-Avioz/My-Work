﻿CREATE DATABASE Project
GO
use Project
GO

-- Use this to delete the database
-- Keep in comment
/*
USE master;
ALTER DATABASE [Project] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DROP DATABASE [Project] ;
*/

CREATE TABLE Animals (
    animal_id INT PRIMARY KEY,
    animal_name VARCHAR(100) NOT NULL,
    medical CHAR(1) NOT NULL CHECK (medical IN ('Y', 'N')),
    birth_date DATE NOT NULL,
    origin VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL
)

CREATE TABLE Zoos (
    zoo_id INT PRIMARY KEY,
    zoo_name VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    country VARCHAR(100) NOT NULL,
    manager VARCHAR(100) NOT NULL,
    ticket_price DECIMAL(5, 2) NOT NULL
)

CREATE TABLE Visitors (
    visitor_id INT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    visit_date DATE NOT NULL
)

CREATE TABLE ZoosVisitors (
    zoo_id INT,
    visitor_id INT,
    PRIMARY KEY (zoo_id, visitor_id),
    FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id),
    FOREIGN KEY (visitor_id) REFERENCES Visitors(visitor_id)
)

CREATE TABLE ZoosAnimals (
    zoo_id INT,
    animal_id INT,
    PRIMARY KEY (zoo_id, animal_id),
    FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id),
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id)
)

CREATE TABLE FavoriteAnimals (
    visitor_id INT,
    animal_id INT,
    PRIMARY KEY (visitor_id, animal_id),
    FOREIGN KEY (visitor_id) REFERENCES Visitors(visitor_id),
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id)
)

CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    salary DECIMAL(10, 2) NOT NULL,
    job_title VARCHAR(100) NOT NULL,
    zoo_id INT,
    FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id)
)

CREATE TABLE Employeespecialties (
    employee_id INT,
    animal_id INT,
	animal_name VARCHAR(100) NOT NULL
    PRIMARY KEY (employee_id, animal_id),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id),
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id)
)

INSERT INTO Animals (animal_id, animal_name, medical, birth_date, origin, type)
VALUES
    (1, 'Lion', 'Y', '2015-02-14', 'Africa', 'Mammal'),
    (2, 'Zebra', 'N', '2018-09-22', 'Africa', 'Mammal'),
    (3, 'Giraffe', 'N', '2012-01-07', 'Africa', 'Mammal'),
    (4, 'Chimpanzee', 'Y', '2009-06-20', 'Africa', 'Mammal'),
    (5, 'Panda', 'N', '2017-11-11', 'China', 'Mammal'),
    (6, 'Red Panda', 'Y', '2020-03-03', 'Himalayas', 'Mammal'),
    (7, 'Koala', 'N', '2016-05-18', 'Australia', 'Marsupial'),
    (8, 'Kangaroo', 'Y', '2019-08-09', 'Australia', 'Marsupial'),
    (9, 'Wombat', 'N', '2021-02-01', 'Australia', 'Marsupial'),
    (10, 'Tasmanian Devil', 'Y', '2018-12-25', 'Tasmania', 'Marsupial'),
    (11, 'Emperor Penguin', 'N', '2020-07-14', 'Antarctica', 'Bird'),
    (12, 'Bald Eagle', 'Y', '2015-04-02', 'North America', 'Bird'),
    (13, 'Toucan', 'N', '2019-01-21', 'South America', 'Bird'),
    (14, 'Macaw', 'N', '2017-10-26', 'South America', 'Bird'),
    (15, 'King Cobra', 'Y', '2012-09-05', 'South Asia', 'Reptile'),
    (16, 'Boa Constrictor', 'N', '2021-05-12', 'Mexico', 'Reptile'),
    (17, 'Komodo Dragon', 'Y', '2018-02-17', 'Indonesia', 'Reptile'),
    (18, 'Green Anaconda', 'N', '2016-08-30', 'South America', 'Reptile'),
    (19, 'Golden Poison Frog', 'Y', '2020-01-10', 'South America', 'Amphibian'),
    (20, 'Axolotl', 'N', '2020-02-26', 'Mexico', 'Amphibian'),
    (21, 'Lion', 'N', '2023-04-11', 'Africa', 'Mammal'),
    (22, 'Zebra', 'Y', '2022-06-21', 'Africa', 'Mammal'),
    (23, 'Kangaroo', 'N', '2020-04-05', 'Australia', 'Marsupial'),
    (24, 'Emperor Penguin', 'Y', '2021-05-08', 'Antarctica', 'Bird'),
    (25, 'Bald Eagle', 'N', '2018-11-19', 'North America', 'Bird'),
    (26, 'Toucan', 'Y', '2022-03-07', 'South America', 'Bird'),
    (27, 'King Cobra', 'N', '2019-02-14', 'South Asia', 'Reptile'),
    (28, 'Komodo Dragon', 'N', '2021-11-23', 'Indonesia', 'Reptile'),
    (29, 'Komodo Dragon', 'Y', '2022-09-09', 'Indonesia', 'Reptile'),
    (30, 'Axolotl', 'Y', '2021-07-10', 'Mexico', 'Amphibian')

	INSERT INTO Visitors (visitor_id, first_name, last_name, visit_date)
VALUES
    (40, 'Alice', 'Johnson', '2024-06-15'),
    (41, 'Bob', 'Williams', '2024-06-12'),
    (42, 'Charlie', 'Garcia', '2024-06-18'),
    (43, 'David', 'Miller', '2024-06-10'),
    (44, 'Charlie', 'Garcia', '2024-07-18'),
    (45, 'Emily', 'Brown', '2024-06-17'),
    (46, 'Emily', 'Brown', '2024-07-17'),
    (47, 'Finn', 'Davis', '2024-06-14'),
    (48, 'Grace', 'Clark', '2024-06-16'),
    (49, 'Henry', 'Lewis', '2024-06-11'),
    (50, 'Isabel', 'Wilson', '2024-06-13'),
    (51, 'Jack', 'Moore', '2024-06-19'),
    (52, 'Olivia', 'Taylor', '2024-06-18'),
    (53, 'Noah', 'Allen', '2024-06-15'),
    (54, 'Sophia', 'Baker', '2024-06-12'),
    (55, 'Liam', 'King', '2024-06-20'),
    (56, 'Ava', 'Campbell', '2024-06-11'),
    (57, 'William', 'Daniels', '2024-06-13'),
    (58, 'Mia', 'Wright', '2024-06-19'),
    (59, 'Ethan', 'Garcia', '2024-06-16'),
    (60, 'Olivia', 'Brown', '2024-06-14'),
    (61, 'Noah', 'Miller', '2024-06-20'),
    (62, 'Sophia', 'Baker', '2024-06-17'),
    (63, 'Liam', 'King', '2024-06-12'),
    (64, 'Ava', 'Campbell', '2024-06-18')

	INSERT INTO Zoos (zoo_id, zoo_name, city, country, manager, ticket_price)
VALUES
    (70, 'Central Park Zoo', 'New York City', 'USA', 'John Smith', 19.95),
    (71, 'Taronga Zoo', 'Sydney', 'Australia', 'Jane Doe', 35.00),
    (72, 'Tiergarten Schönbrunn', 'Vienna', 'Austria', 'Anna Schmidt', 22.50),
    (73, 'Singapore Zoo', 'Singapore', 'Singapore', 'David Lee', 30.00),
    (74, 'Pairi Daiza', 'Bruges', 'Belgium', 'Marie Dubois', 38.00)

	INSERT INTO ZoosAnimals (zoo_id, animal_id)
VALUES
    (70, 1), (70, 2), (70, 3), (70, 4), (70, 5), (70, 6),
    (71, 7), (71, 8), (71, 9), (71, 10), (71, 11), (71, 12),
    (72, 13), (72, 14), (72, 15), (72, 16), (72, 17), (72, 18),
    (73, 19), (73, 20), (73, 21), (73, 22), (73, 23), (73, 24),
    (74, 25), (74, 26), (74, 27), (74, 28), (74, 29), (74, 30)

	INSERT INTO ZoosVisitors (zoo_id, visitor_id)
VALUES
    (70, 40), (70, 45), (70, 49), (70, 52), (70, 56), (70, 59), (70, 62),
    (71, 41), (71, 46), (71, 50), (71, 55), (71, 60),
    (72, 42), (72, 47), (72, 53), (72, 58), (72, 64),
    (73, 44), (73, 48), (73, 51), (73, 63),
    (74, 43), (74, 54), (74, 57), (74, 61)

	INSERT INTO Employees (employee_id, first_name, last_name, start_date, end_date, salary, job_title, zoo_id)
VALUES
    (90, 'Alice', 'David', '2023-01-15', NULL, 72500.00, 'Zookeeper', 70),
    (91, 'Bob', 'Hadar', '2022-06-01', NULL, 65000.00, 'Veterinarian', 70),
    (92, 'Charlie', 'Levin', '2021-12-20', '2024-03-31', 58000.00, 'Animal Trainer', 70),
    (93, 'David', 'Zafrani', '2024-05-10', NULL, 48000.00, 'Zookeeper Assistant', 70),
    (94, 'Emily', 'Avioz', '2020-08-12', NULL, 85000.00, 'Head Curator', 71),
    (95, 'Finn', 'Laor', '2023-09-05', NULL, 60000.00, 'Herpetologist', 71),
    (96, 'Grace', 'Cohen', '2022-02-14', NULL, 52000.00, 'Aquarium Specialist', 71),
    (97, 'Henry', 'Zuck', '2021-10-26', NULL, 78000.00, 'Lead Veterinarian', 71),
    (98, 'Isabel', 'Hindi', '2024-04-15', NULL, 50000.00, 'Animal Enrichment Specialist', 72),
    (99, 'Jack', 'Black', '2023-07-01', NULL, 62000.00, 'Lead Veterinarian', 72),
    (100, 'Olivia', 'Maor', '2022-05-09', NULL, 45000.00, 'Volunteer Coordinator', 72),
    (101, 'Noah', 'Cavilo', '2021-11-21', NULL, 55000.00, 'Education Specialist', 72),
    (102, 'Sophia', 'Shay', '2024-02-02', NULL, 80000.00, 'Research Scientist', 73),
    (103, 'Liam', 'Fader', '2023-03-12', NULL, 68000.00, 'Marketing Manager', 73),
    (104, 'Ava', 'Mor', '2022-01-18', '2024-05-31', 53000.00, 'Veterinarian Technician', 73),
    (105, 'William', 'Bar', '2021-09-09', NULL, 70000.00, 'Conservation Specialist', 73),
    (106, 'Mia', 'Hock', '2024-06-10', NULL, 52000.00, 'Intern', 74),
    (107, 'Ethan', 'Boosh', '2023-04-04', NULL, 63000.00, 'Animal Care Supervisor', 74),
    (108, 'Olivia', 'Stern', '2022-02-14', NULL, 51000.00, 'Gift Shop Manager', 74),
    (109, 'Noah', 'Ben', '2021-10-21', NULL, 75000.00, 'Marketing Manager', 74)

	INSERT INTO Employeespecialties (employee_id,animal_id,animal_name)
VALUES
    (90,1, 'Lion'),
    (90,2, 'Zebra'),
    (90,3, 'Giraffe'),
    (91,4, 'Chimpanzee'),
    (91,5, 'Panda'),
    (91,6, 'Red Panda'),
    (92,7, 'Koala'),
    (92,8, 'Kangaroo'),
    (92,9, 'Wombat'),
    (93,10, 'Tasmanian Devil'),
    (93,11, 'Emperor Penguin'),
    (93,12, 'Bald Eagle'),
    (94,13, 'Toucan'),
    (94,14, 'Macaw'),
    (94,15, 'King Cobra'),
    (95,16, 'Boa Constrictor'),
    (95,17, 'Komodo Dragon'),
    (95,18, 'Green Anaconda'),
    (97,1, 'Lion'),
    (97,2, 'Zebra'),
    (97,30, 'Axoltol'),
    (98,19, 'Golden Poison Frog'),
    (98,30, 'Axoltol'),
    (99,19, 'Golden Poison Frog'),
    (99,30, 'Axoltol'),
    (100,1, 'Lion'),
    (100,2, 'Zebra'),
    (100,4, 'Chimpanzee'),
    (101,5, 'Panda'),
    (102,4, 'Chimpanzee'),
    (102,5, 'Panda'),
    (102,6, 'Red Panda'),
    (104,1, 'Lion'),
    (104,2, 'Zebra'),
    (104,3, 'Giraffe'),
    (105,11, 'Emperor Penguin'),
    (105,12, 'Bald Eagle'),
    (105,10, 'Tasmanian Devil'),
    (106,7, 'Koala'),
    (107,7, 'Koala'),
    (107,8, 'Kangaroo'),
    (107,9, 'Wombat')

	INSERT INTO FavoriteAnimals (visitor_id, animal_id)
VALUES
    (40, 3),   -- Alice Johnson likes Giraffe
    (40, 5),   -- Alice Johnson likes Panda
    (41, 1),   -- Bob Williams likes Lion
    (41, 2),   -- Bob Williams likes Zebra
    (42, 7),   -- Charlie Garcia likes Koala
    (42, 9),   -- Charlie Garcia likes Wombat
    (43, 17),  -- David Miller likes Komodo Dragon
    (43, 15),  -- David Miller likes King Cobra
    (44, 7),   -- Charlie Garcia likes Koala
    (44, 9),   -- Charlie Garcia likes Wombat
    (45, 11),  -- Emily Brown likes Emperor Penguin
    (45, 13),  -- Emily Brown likes Toucan
    (46, 11),  -- Emily Brown likes Emperor Penguin
    (46, 13),  -- Emily Brown likes Toucan
    (47, 4),   -- Finn Davis likes Chimpanzee
    (47, 6),   -- Finn Davis likes Red Panda
    (48, 14),  -- Grace Clark likes Macaw
    (48, 19),  -- Grace Clark likes Golden Poison Frog
    (49, 1),   -- Henry Lewis likes Lion
    (49, 2),   -- Henry Lewis likes Zebra
    (50, 7),   -- Isabel Wilson likes Koala
    (50, 9),   -- Isabel Wilson likes Wombat
    (51, 10),  -- Jack Moore likes Tasmanian Devil
    (51, 16),  -- Jack Moore likes Boa Constrictor
    (52, 3),   -- Olivia Taylor likes Giraffe
    (52, 6),   -- Olivia Taylor likes Red Panda
    (53, 15),  -- Noah Allen likes King Cobra
    (53, 18),  -- Noah Allen likes Green Anaconda
    (54, 5),   -- Sophia Baker likes Panda
    (55, 8),   -- Liam King likes Kangaroo
    (55, 7),   -- Liam King likes Koala
    (56, 11),  -- Ava Campbell likes Emperor Penguin
    (56, 13),  -- Ava Campbell likes Toucan
    (57, 17),  -- William Daniels likes Komodo Dragon
    (57, 16),  -- William Daniels likes Boa Constrictor
    (58, 4),   -- Mia Wright likes Chimpanzee
    (58, 7),   -- Mia Wright likes Koala
    (59, 2),   -- Ethan Garcia likes Zebra
    (59, 3),   -- Ethan Garcia likes Giraffe
    (60, 12),  -- Olivia Brown likes Bald Eagle
    (60, 14),  -- Olivia Brown likes Macaw
    (61, 20),  -- Noah Miller likes Axolotl
    (61, 19),  -- Noah Miller likes Golden Poison Frog
    (62, 5),   -- Sophia Baker likes Panda
    (62, 6),   -- Sophia Baker likes Red Panda
    (63, 10),  -- Liam King likes Tasmanian Devil
    (63, 7),   -- Liam King likes Koala
    (64, 1),   -- Ava Campbell likes Lion
    (64, 7)   -- Ava Campbell likes Koala
-- יצירת טבלת עזר כדי לשמור את ההוצאות
create table Zoos_Outcomes(
	zoo_id int,
	zoo_name varchar(100),
	outcomes float,
	PRIMARY KEY (zoo_id),
    FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id),
)

-- יצירת טבלת עזר הכנסות
create table Tbl_Tot_Income
(
	zoo_id int,
	zoo_name varchar (100),
	tot_income float,
	PRIMARY KEY (zoo_id),
    FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id),
)

-- ייבוא טבלת אקסל - הזמנות של מוצרי מזון שונים עבור החיות
drop table orders
create table Orders
(
	order_id int primary key,
	product varchar(50) not null, 
	quantity int not null,
	price int not null,
	zoo_id int not null
	FOREIGN KEY (zoo_id) REFERENCES Zoos(zoo_id)
)