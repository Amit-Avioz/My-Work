﻿-- מחיקת טריגר "עדכון טבלת עובדים" אם קיים
IF EXISTS ( SELECT name FROM sysobjects
			WHERE type = 'TR' AND name = 'Employees_Salary_Update' )
DROP TRIGGER Employees_Salary_Update
go

-- יצירת טריגר לעדכון "הוצאות לכל גן חיות" לאחר שינוי משכורת העובדים
create or alter trigger Employees_Salary_Update
	on Employees for update
as
	if update(Salary)
		begin
			declare @new_outcomes float, @zoo_id int
			select @new_outcomes = (select sum(salary) from inserted)
			select @zoo_id = (select zoo_id from inserted group by zoo_id)
			update zoos_outcomes set outcomes = @new_outcomes where zoo_id = @zoo_id
		end
go

-- מחיקת טריגר "עדכון הוצאות לכל גן חיות" אם קיים
IF EXISTS ( SELECT name FROM sysobjects
			WHERE type = 'TR' AND name = 'Orders_Insert' )
DROP TRIGGER Orders_Insert
go

-- לאחר יצירת הזמנה חדשה, ניצור טריגר לעדכון הוצאות לכל גן חיות
create or alter trigger Orders_Insert
	on Orders for insert
as
	update Zoos_Outcomes
	set outcomes = (Zoos_Outcomes.outcomes + inserted.price)
	from Zoos_Outcomes inner join inserted
	on Zoos_Outcomes.zoo_id = inserted.zoo_id
go

select * from orders
select * from Zoos_Outcomes

-- בדיקת הטריגר
insert Orders (order_id, product, quantity, price, zoo_id)
values (16, 'fruits', 900, 800, 74)

select * from orders
select * from Zoos_Outcomes

-- Proc + Transcation
-- עבור גן החיות עם הכי הרבה מבקרים, העובדים יקבלו בונוס של 10% למשכורת
create or alter proc Raise_Employees_Salary
as
	declare @best_zoo_name varchar(100)
	select top 1 @best_zoo_name =  zoo_name from Visitors_Counter order by [Visitors Counter] desc 
	begin transaction
		update Employees set salary = salary * 1.1 where Employees.zoo_id = (select zoo_id from ZooEmployees where zoo_name = @best_zoo_name group by zoo_id)
		if (@@ERROR <> 0)
			begin
				rollback transaction
				return
			end
	commit transaction
go