﻿-- כמות מבקרים לכל גן חיות
create or alter view Visitors_Counter
as
	SELECT dbo.Zoos.zoo_name, dbo.ZoosVisitors.zoo_id, COUNT(dbo.ZoosVisitors.visitor_id) AS [Visitors Counter]
	FROM     dbo.Zoos INNER JOIN
					  dbo.ZoosVisitors ON dbo.Zoos.zoo_id = dbo.ZoosVisitors.zoo_id
	GROUP BY dbo.Zoos.zoo_name, dbo.ZoosVisitors.zoo_id
go

select * from Visitors_Counter
go

-- חיבור בין טבלת העובדים לבין טבלת גני החיות
create or alter view ZooEmployees
as
	select Zoos.zoo_id, Zoos.zoo_name, first_name, last_name, salary from Zoos, Employees
	where Zoos.zoo_id = Employees.zoo_id
go

-- חיבור בין הטבלאות של גני חיות וחיות
create or alter view AnimalsInZoosFull
as
	SELECT dbo.Animals.animal_name, dbo.Animals.medical, dbo.Animals.birth_date, dbo.Animals.origin, dbo.Animals.type, dbo.Zoos.zoo_name, dbo.Zoos.city, dbo.Zoos.country, dbo.Zoos.ticket_price, dbo.Zoos.manager
	FROM     dbo.Animals INNER JOIN
			 dbo.ZoosAnimals ON dbo.Animals.animal_id = dbo.ZoosAnimals.animal_id INNER JOIN
			 dbo.Zoos ON dbo.ZoosAnimals.zoo_id = dbo.Zoos.zoo_id INNER JOIN
			 dbo.Animals AS Animals_1 ON dbo.ZoosAnimals.animal_id = Animals_1.animal_id INNER JOIN
		     dbo.Zoos AS Zoos_1 ON dbo.ZoosAnimals.zoo_id = Zoos_1.zoo_id INNER JOIN
			 dbo.ZoosAnimals AS ZoosAnimals_1 ON dbo.Animals.animal_id = ZoosAnimals_1.animal_id AND dbo.Zoos.zoo_id = ZoosAnimals_1.zoo_id AND Animals_1.animal_id = ZoosAnimals_1.animal_id AND Zoos_1.zoo_id = ZoosAnimals_1.zoo_id
go

select * from AnimalsInZoosFull

-- חיבור הטבלאות חיות אהובות ומבקרים
create or alter view FavoriteAnimalsFullInfo
as
	SELECT dbo.Visitors.first_name, dbo.Visitors.last_name, dbo.Animals.animal_id, dbo.Animals.animal_name, dbo.Animals.medical, dbo.Animals.birth_date, dbo.Animals.type, dbo.Animals.origin
	FROM     dbo.Animals INNER JOIN
                  dbo.FavoriteAnimals ON dbo.Animals.animal_id = dbo.FavoriteAnimals.animal_id INNER JOIN
                  dbo.Visitors ON dbo.FavoriteAnimals.visitor_id = dbo.Visitors.visitor_id
go

-- איחוד הטבלאות מבקרים וגני חיות
create or alter view VisitorsInZoos
as
	SELECT dbo.Zoos.zoo_name, dbo.Visitors.first_name, dbo.Visitors.last_name, dbo.Visitors.visit_date, dbo.Visitors.visitor_id
	FROM     dbo.Visitors INNER JOIN
                  dbo.ZoosVisitors ON dbo.Visitors.visitor_id = dbo.ZoosVisitors.visitor_id INNER JOIN
                  dbo.Zoos ON dbo.ZoosVisitors.zoo_id = dbo.Zoos.zoo_id
go